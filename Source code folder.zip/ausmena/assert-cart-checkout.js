// Load and render the cart
function renderCart() {
  const cartItems = JSON.parse(localStorage.getItem('cart')) || [];
  const cartItemsContainer = document.getElementById('cartItems');
  const totalPriceElement = document.getElementById('totalPrice');
  cartItemsContainer.innerHTML = '';
  let total = 0;

  if (!cartItems.length) {
    cartItemsContainer.innerHTML = '<p>Your cart is empty.</p>';
    totalPriceElement.textContent = '0.00';
    return;
  }

  cartItems.forEach((item, index) => {
    const itemTotal = item.price * item.quantity;
    total += itemTotal;

    const itemElement = document.createElement('div');
    itemElement.classList.add('card', 'mb-3');
    itemElement.innerHTML = `
      <div class="card-body">
        <h5 class="card-title">${item.name}</h5>
        <p class="card-text">Item 1: ${item.meat || 'None'}</p>
        <p class="card-text">Item 2: ${item.sauces && item.sauces.length ? item.sauces.join(', ') : 'None'}</p>
        <p class="card-text">Price: €${item.price.toFixed(2)}</p>
        <div class="d-flex align-items-center">
          <button class="btn btn-sm btn-outline-secondary mr-2" onclick="updateQuantity(${index}, -1)">-</button>
          <span>${item.quantity}</span>
          <button class="btn btn-sm btn-outline-secondary ml-2" onclick="updateQuantity(${index}, 1)">+</button>
          <button class="btn btn-sm btn-danger ml-3" onclick="removeItem(${index})">Remove</button>
        </div>
      </div>
    `;
    cartItemsContainer.appendChild(itemElement);
  });

  totalPriceElement.textContent = total.toFixed(2);
}

function updateQuantity(index, change) {
  const cartItems = JSON.parse(localStorage.getItem('cart')) || [];
  cartItems[index].quantity += change;
  if (cartItems[index].quantity < 1) cartItems[index].quantity = 1;
  localStorage.setItem('cart', JSON.stringify(cartItems));
  renderCart();
}

function removeItem(index) {
  const cartItems = JSON.parse(localStorage.getItem('cart')) || [];
  cartItems.splice(index, 1);
  localStorage.setItem('cart', JSON.stringify(cartItems));
  renderCart();
}

document.addEventListener('DOMContentLoaded', function () {
  renderCart();

  const checkoutForm = document.getElementById('checkoutForm');
  if (checkoutForm) {
    checkoutForm.addEventListener('submit', function (e) {
      e.preventDefault();

      const name = document.getElementById('name').value.trim();
      const phone = document.getElementById('phone').value.trim();
      const notes = document.getElementById('notes').value.trim();
      const paymentMethod = document.querySelector('input[name="paymentMethod"]:checked').value;

      const cart = JSON.parse(localStorage.getItem('cart')) || [];
      const total = document.getElementById('totalPrice').textContent;

      if (!cart.length) {
        alert('Your cart is empty.');
        return;
      }

      if (!name || !phone) {
        alert('Please fill in all required fields.');
        return;
      }

      // Simulate order processing
      if (paymentMethod === 'cash') {
        alert(`Order confirmed with Cash on Delivery!\n\nThank you, ${name}.\nWe will contact you at ${phone}.\n\nItems: ${cart.length}\nTotal: $${total}`);
      } else if (paymentMethod === 'stripe') {
        alert('Redirecting to Stripe payment gateway... (simulated)');
        alert(`Payment successful!\n\nThank you, ${name}.`);
      }

      // ✅ Save order for receipt and generate receipt
      localStorage.setItem('lastOrder', JSON.stringify(cart));
      downloadReceipt();

      // ✅ Clear cart
      localStorage.removeItem('cart');
      window.location.reload();
    });
  }
});

// 🧾 Receipt Generator
async function downloadReceipt() {
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();

  const cart = JSON.parse(localStorage.getItem("lastOrder") || "[]");
  if (!cart.length) {
    alert("No receipt available. Please complete a checkout first.");
    return;
  }

  const taxRate = 0.1;
  let subtotal = 0;
  const now = new Date();
  const orderId = "ORD-" + now.getTime();
  const dateStr = now.toLocaleString();
  const pageWidth = doc.internal.pageSize.getWidth();

  // Header (without logo)
  doc.setFontSize(14);
  doc.text("Ausmena Kebabs", 15, 15);
  doc.setFontSize(10);
  doc.text("Riga, Latvia\nPhone: +371 12345678\nwww.ausmenakebabs.lv", 15, 20);

  // Metadata
  doc.setFontSize(12);
  doc.text(`Receipt #: ${orderId}`, 15, 40);
  doc.text(`Date: ${dateStr}`, 15, 47);

  // Table headers
  let y = 60;
  doc.setFontSize(11);
  doc.setFont("helvetica", "bold");
  doc.text("Qty", 15, y);
  doc.text("Item", 30, y);
  doc.text("Extras", 90, y);
  doc.text("Price", 170, y, { align: "right" });
  doc.setFont("helvetica", "normal");
  y += 6;

  // Table rows
  cart.forEach(item => {
    doc.text(item.quantity?.toString() || "1", 15, y);
    doc.text(item.name, 30, y);
    doc.text((item.options || []).join(", "), 90, y);
    const itemTotal = item.price * (item.quantity || 1);
    doc.text(`€${itemTotal.toFixed(2)}`, 170, y, { align: "right" });
    y += 8;
    subtotal += itemTotal;
  });

  const tax = subtotal * taxRate;
  const total = subtotal + tax;

  // Summary
  y += 10;
  doc.line(15, y, pageWidth - 15, y);
  y += 6;
  doc.text(`Subtotal:`, 150, y);
  doc.text(`€${subtotal.toFixed(2)}`, 200, y, { align: "right" });

  y += 6;
  doc.text(`Tax (10%):`, 150, y);
  doc.text(`€${tax.toFixed(2)}`, 200, y, { align: "right" });

  y += 6;
  doc.setFont("helvetica", "bold");
  doc.text(`Total:`, 150, y);
  doc.text(`€${total.toFixed(2)}`, 200, y, { align: "right" });

  // Footer
  y += 20;
  doc.setFont("helvetica", "italic");
  doc.setFontSize(10);
  doc.text("Thank you for ordering from Ausmena Kebabs!", 15, y);

  // Save
  doc.save(`AusmenaKebabs_Receipt_${orderId}.pdf`);
}
